package com.sathyatel.Friend.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.Friend.entity.Friend;
import com.sathyatel.Friend.repository.FriendRepository;
import com.sathyatel.Friend.service.IFriendService;
@Service
public class FriendServiceImpl implements IFriendService{
	@Autowired
	FriendRepository repository;

	@Override
	public String addFriendService(Friend friend) {
		Integer count =repository.VerifyFriendNo(friend.getPhoneNo(),friend.getFriendNo());
		if(count==0) {
			repository.save(friend);
			return "Friend Contact is added";
		}else
			return "Friend contact already exist";
	}

	@Override
	public List<Long> getFriendsContactService(Long phoneNo) {
		List<Friend> friendList=repository.findByPhoneNo(phoneNo);
		List<Long> friendsContactList=new ArrayList<Long>();
		for(Friend friend:friendList) {
			friendsContactList.add(friend.getFriendNo());
		}
		return friendsContactList;
	}
}


