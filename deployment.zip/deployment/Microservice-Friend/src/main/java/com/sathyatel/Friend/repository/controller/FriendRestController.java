package com.sathyatel.Friend.repository.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.Friend.entity.Friend;
import com.sathyatel.Friend.service.IFriendService;
@RestController
public class FriendRestController {
	@Autowired
	IFriendService service;

	@PostMapping(value="/addFriend",produces="application/json")
	public String addFriend(@RequestBody Friend friend) {
		return service.addFriendService(friend);
	}


	@GetMapping(value="/friends/{phoneNo}",produces="application/json") public
	List<Long> getFriends(@PathVariable Long phoneNo){ 
		return  service.getFriendsContactService(phoneNo);

	}
}
