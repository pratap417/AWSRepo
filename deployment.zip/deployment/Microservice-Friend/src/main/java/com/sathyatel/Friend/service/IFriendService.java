package com.sathyatel.Friend.service;

import java.util.List;

import com.sathyatel.Friend.entity.Friend;

public interface IFriendService {
	String addFriendService(Friend friend);
	List<Long> getFriendsContactService(Long phoneNo);
}
