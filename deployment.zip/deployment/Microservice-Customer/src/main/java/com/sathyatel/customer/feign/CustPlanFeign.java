package com.sathyatel.customer.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sathyatel.customer.model.PlanDTO;

@FeignClient("planDetailsMS")
public interface CustPlanFeign {
	@RequestMapping("/PlanDetailsApi/{planId}")
	public PlanDTO getSpecificPlan(@PathVariable("planId") String planId);
}
