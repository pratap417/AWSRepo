package com.sathyatel.customer.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.command.AsyncResult;
import com.sathyatel.customer.feign.CustFriendFeign;
import com.sathyatel.customer.feign.CustPlanFeign;
import com.sathyatel.customer.model.PlanDTO;

@Service
public class CustomerCircuitService {
	private static String FRIEND_URL="http://friendMS/FriendApi/friends/{phoneNo}";
	private static String PLAN_URL = "http://planDetailsMS/PlanDetailsApi/{planId}";
	@Autowired
	RestTemplate restTemplate;

	//@Autowired
	//CustPlanFeign pfeign;
	//@Autowired
	//CustFriendFeign ffeign;



	@HystrixCommand(fallbackMethod="getFriendsFallback")
	public List<Long> getFriends(Long phoneNo){
		return restTemplate.getForObject(FRIEND_URL,List.class,phoneNo);// 
		//feign client
		//return ffeign.getFriendsNumbers(phoneNo);
	}

	public List<Long> getFriendsFallback(Long phoneNo){
		return new ArrayList<>();
	}

	public Future<PlanDTO> getPlanData(String planId){
		return new AsyncResult<PlanDTO>() {
			public PlanDTO invoke() {
				return restTemplate.getForObject(PLAN_URL, PlanDTO.class,planId);
				//Using feign client
				//return pfeign.getSpecificPlan(planId);

			}
		};
	}
}
