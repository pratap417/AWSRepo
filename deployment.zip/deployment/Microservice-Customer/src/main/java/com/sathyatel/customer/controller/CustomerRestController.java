package com.sathyatel.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sathyatel.customer.entity.Customer;
import com.sathyatel.customer.model.CustomerDTO;
import com.sathyatel.customer.model.Login;
import com.sathyatel.customer.model.PlanDTO;
import com.sathyatel.customer.service.ICustomerService;

@RestController
@RibbonClient(name="custribbon")
public class CustomerRestController {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	private ICustomerService service;
	//@Autowired
	//CustomerCircuitService circuit; 


	@PostMapping(value="/register",  consumes="application/json")
	public    String    registerCustomer(@RequestBody   Customer  customer) {
		boolean flag=service.addCustomer(customer);
		{ if(flag==true) { return
				"Customer registered sccessfully"; 
		}else { 
			return "Customer already exists";
		}
		} 
	}

	@PostMapping(value="/login",  consumes="application/json")
	public boolean verifyLogin(@RequestBody  Login   login) {
		return service.checkLogin(login);
	}

	@GetMapping(value="/viewProfile/{phoneNo}", produces="application/json")
	public CustomerDTO getCustomerProfile(@PathVariable Long phoneNo) {
		//String URL_1 = "http://localhost:5556/PlanDetailsApi/{planId}";//PlanMS URL
		//String URL_2 = "http://localhost:5577/FriendApi/friends/{phoneNo}";//FriendMs URL
		//String URL_2 = "http://custribbon/FriendApi/friends/{phoneNo}";//Calling Load balanced component Ribbon without eureka
		String URL_1 = "http://planDetailsMS/PlanDetailsApi/{planId}";//Calling PlanDetailsMS URL with application name plandetailsMS(Eureka Instances) 
		String URL_2 = "http://friendMS/FriendApi/friends/{phoneNo}";//Calling FriendMS URL with application name plandetailsMS(Eureka Instance)
		CustomerDTO customerDto=service.getCustomerDetails(phoneNo);
		//Call PlanDetailsMicroservice
		PlanDTO planDto = restTemplate.getForObject(URL_1,PlanDTO.class,customerDto.getPlanId());
		customerDto.setCurrentPLan(planDto);
		
		//Asynchronous Communication
		/**long x=System.currentTimeMillis();
		Future<PlanDTO> future=circuit.getPlanData(customerDto.getPlanId());
		try {
			customerDto.setCurrentPLan(future.get());
		}catch(Exception e) {
			
		}**/
		
		//Call FriendMicroservice
		List<Long> friendsNo=restTemplate.getForObject(URL_2,List.class,customerDto.getPhoneNo());
		//List<Long>friendsContactNumbers=circuit.getFriends(customerDto.getPhoneNo());
		customerDto.setFriends(friendsNo);
		/*
		 * long y=System.currentTimeMillis();
		 * System.out.println("Time taken in milliseconds:"+(y-x));
		 */
		customerDto.setCurrentPLan(planDto); 
		return customerDto;
	}
}













