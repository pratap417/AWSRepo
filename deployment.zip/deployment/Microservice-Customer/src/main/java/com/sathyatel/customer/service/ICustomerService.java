package com.sathyatel.customer.service;

import com.sathyatel.customer.entity.Customer;
import com.sathyatel.customer.model.CustomerDTO;
import com.sathyatel.customer.model.Login;



public interface ICustomerService {
	boolean addCustomer(Customer customer);
	
	 boolean checkLogin(Login login);
	 CustomerDTO   getCustomerDetails(Long  phoneNo);
	
}
