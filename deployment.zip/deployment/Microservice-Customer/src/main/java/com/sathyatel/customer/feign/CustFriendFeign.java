package com.sathyatel.customer.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient("friendMS")
public interface CustFriendFeign {
	@RequestMapping("/FriendApi/friends/{phoneNo}")
	public List<Long> getFriendsNumbers(@PathVariable("phoneNO") Long phoneNO);
}

