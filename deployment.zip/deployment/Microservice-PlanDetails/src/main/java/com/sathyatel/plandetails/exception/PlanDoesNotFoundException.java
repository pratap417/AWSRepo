package com.sathyatel.plandetails.exception;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class PlanDoesNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;
	@ExceptionHandler(PlanDoesNotFoundException.class)
	public String exceptionHandler(PlanDoesNotFoundException e) {
		return "Sorry!!! Selected plan not available";
	}
}
