package com.sathyatel.plandetails.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.plandetails.dto.PlanDTO;
import com.sathyatel.plandetails.entity.Plan;
import com.sathyatel.plandetails.repository.PlanRepository;
import com.sathyatel.plandetails.service.IPlanService;
@Service
public class PlanServiceImpl implements IPlanService {
	@Autowired
	PlanRepository repository;
	@Override
	public List<PlanDTO> getAllPlans() {
		List<Plan> planList=repository.findAll();
		List<PlanDTO> planDTOList=new ArrayList<PlanDTO>();
		for(Plan plan:planList) {
			PlanDTO dto=new PlanDTO();
			BeanUtils.copyProperties(plan, dto);
			planDTOList.add(dto);
		}
		return planDTOList;
	}

	@Override
	public PlanDTO getSpecificPlan(String planId) {
		Optional<Plan> opt=repository.findById(planId);
		Plan plan=opt.get();
		PlanDTO dto=new PlanDTO();
		BeanUtils.copyProperties(plan, dto);
		return dto;
	}
}
