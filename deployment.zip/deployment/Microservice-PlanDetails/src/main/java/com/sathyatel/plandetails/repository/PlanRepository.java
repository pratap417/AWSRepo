package com.sathyatel.plandetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sathyatel.plandetails.entity.Plan;

public interface PlanRepository extends JpaRepository<Plan, String> {

}
